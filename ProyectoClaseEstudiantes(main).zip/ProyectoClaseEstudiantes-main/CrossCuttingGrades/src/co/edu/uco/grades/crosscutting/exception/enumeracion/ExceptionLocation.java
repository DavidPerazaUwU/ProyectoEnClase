package co.edu.uco.grades.crosscutting.exception.enumeracion;

public enum ExceptionLocation {
	DATA, BUSINESS_LOGIC,API,DTO,CROSS_CUTTING, GENERAL

}
