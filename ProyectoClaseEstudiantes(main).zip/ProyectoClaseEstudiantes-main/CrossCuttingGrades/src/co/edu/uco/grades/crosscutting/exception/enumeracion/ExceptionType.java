package co.edu.uco.grades.crosscutting.exception.enumeracion;

public enum ExceptionType {

	TECHNICAL, BUSINESS, GENERAL

}
