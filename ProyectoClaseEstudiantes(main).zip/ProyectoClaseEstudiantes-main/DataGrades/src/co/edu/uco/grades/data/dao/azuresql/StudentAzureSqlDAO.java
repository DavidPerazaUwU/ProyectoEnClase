package co.edu.uco.grades.data.dao.azuresql;

import co.edu.uco.grade.dto.StudentDTO;
import co.edu.uco.grades.data.dao.StundentDAO;

public class StudentAzureSqlDAO implements StundentDAO{

	@Override
	public void create(StudentDTO stundent) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(StudentDTO student) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Delete(int id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void find(StudentDTO stundent) {
		// TODO Auto-generated method stub
		
	}
	
	
}
